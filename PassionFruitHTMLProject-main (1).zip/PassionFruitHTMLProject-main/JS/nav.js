
let value="<header class='sticky-header'><h1>PASSION FRUIT</h1><nav><ul><li> <a href='home.html' style='color:orange;'> Home </a> </li><li> <a href='about.html' style='color:orange;'> About </a> </li><li> <a href='council.html' style='color:orange;'> Student Council </a> </li> <li> <a href='archives.html' style='color:orange;'> Archives </a> </li><li> <a href='calender.html' style='color:orange;'> Calendar </a> </li><li> <a href='scores.html' style='color:orange;'> Scores </a> </li></ul></nav></header>"
document.getElementById("navheader").innerHTML=value;

